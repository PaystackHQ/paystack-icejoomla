# paystack-icejoomla
Paystack Plugin for Icejoomla Payments
